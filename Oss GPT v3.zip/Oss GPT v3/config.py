# إعدادات التكوين
DATA_FILE = "data.json"