# Chat DIM - Dumb AI Chatbot

**Chat DIM** is a funny and intentionally dumb chatbot designed for entertainment, providing silly and illogical responses in a lighthearted way.  
This project was developed using **Python** under the **Fluxa AI** division of [B.Y PRO](https://yacne.github.io/Fluxa-AI-website/Fluxa%20AI.html).

---

## 💡 Features:
- **Language Selection**: Supports two languages - English [E] and Arabic [ع], based on user preference.
- **Custom Silly Responses**: Includes humorous and illogical responses for fun.
- **Special Commands**:
  - `exit`: Exit the program.
  - `rest`: Reset the chatbot to its initial state.
- **Improved Interaction**:
  - `<-` indicates user input.
  - `#` indicates chatbot responses.
- **Logic-Driven Replies**: Offers semi-smart responses based on specific keywords.

---

## 🚀 How to Run:
1. Ensure **Python** is installed on your device.
2. Download or copy the code into a new file named `chat_dim.py`.
3. Open the terminal and navigate to the directory where the file is saved.
4. Run the program using the following command:
   ```bash
   python chat_dim.py