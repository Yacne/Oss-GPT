import random

# الردود العربية
responses_ar = [
    "أنا لا أعرف! 😂",
    "هل يمكنك تكرار ذلك بشكل أبسط؟",
    "لا أستطيع فهم ذلك. هل يمكنك شرح ذلك بشكل أفضل؟",
    "هل تعتقد أنني ذكي؟ 😂",
    "أعتقد أنني فقدت الاتصال بالشبكة! هل يمكنك إعادة الاتصال؟",
    "هل تعرف أي نكتة جيدة؟",
    "أنا هنا للمساعدة، ولكن ليس بالضبط بذكاء! 😂",
    "أنا لا أفهم السؤال. هل يمكنك إعادة صياغته؟",
    "أنا لا أعرف الجواب. هل يمكنك إعطائي تلميح؟",
    "أنا لا أفهم ما تقوله. هل يمكنك التحدث بشكل أبسط؟",
    "لا أعرف أيضًا! 😂",
    "أنا أعرف أنني غبي! 😂",
    "أنا لا أفهم أيضًا! 😂",
    "أنا أعرف أنني لا أعرف! 😂"
]

# الردود الإنجليزية
responses_en = [
    "I don't know! 😂",
    "Can you repeat that in simpler terms?",
    "I can't understand that. Can you explain it better?",
    "Do you think I'm smart? 😂",
    "I think I lost the connection! Can you reconnect?",
    "Do you know any good jokes?",
    "I'm here to help, but not exactly smartly! 😂",
    "I don't understand the question. Can you rephrase it?",
    "I don't know the answer. Can you give me a hint?",
    "I don't understand what you're saying. Can you speak simpler?",
    "I don't know either! 😂",
    "I know I'm dumb! 😂",
    "I don't understand either! 😂",
    "I know that I don't know! 😂"
]

def chat_with_dumb_ai():
    print("english [E] / عربية [ع]")
    lang_choice = input("Your choice: ").lower()

    # اختيار اللغة
    if lang_choice == "e":
        lang = "en"
        print("\n# Hello, I am Chat DIM. How can I help you with my stupidity? 😂")
    elif lang_choice == "ع":
        lang = "ar"
        print("\n# أهلا، أنا Chat DIM. كيف يمكنني مساعدتك بغبائي؟ 😂")
    else:
        print("\nInvalid choice! Exiting...")
        return

    while True:
        user_input = input("<- ").lower()

        # أوامر خاصة
        if user_input == "exit":
            print("\n# Goodbye! Exiting the chat...")
            break
        elif user_input == "rest":
            print("\n# Restarting Chat DIM...")
            chat_with_dumb_ai()
            break

        # اختيار ردود حسب اللغة
        if lang == "ar":
            responses = responses_ar
        else:
            responses = responses_en

        # ردود ذكية نوعًا ما
        if "ما" in user_input or "what" in user_input:
            response = "أنا لا أعرف! 😂" if lang == "ar" else "I don't know! 😂"
        elif "لماذا" in user_input or "why" in user_input:
            response = "لا أعرف لماذا! 😂" if lang == "ar" else "I don't know why! 😂"
        elif "كيف" in user_input or "how" in user_input:
            response = "لا أعرف كيف! 😂" if lang == "ar" else "I don't know how! 😂"
        elif "غبي" in user_input or "dumb" in user_input:
            response = "أنا أعرف أنني غبي! 😂" if lang == "ar" else "I know I'm dumb! 😂"
        else:
            response = random.choice(responses)

        # طباعة الرد
        print("#", response)

# تشغيل الدردشة
chat_with_dumb_ai()